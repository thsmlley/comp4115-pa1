select customerName from customers where creditLimit > 100000;

select city, count(*) from customers group by city;

select customerName from customers t1 join payments t2 on t1.customerNumber = t2.customerNumber where amount >50000;

select * from employees where officeCode = 
(select officeCode from offices where city = "Boston");

select customerName from customers where city IN (select city from offices);

select productName from products where productCode not in (select productCode from orderdetails);

select customerName from customers where customerNumber IN 
(select customerNumber from orders where orderNumber IN
(select orderNumber from orderdetails where productCode IN
(select productCode from products where productLine = "Classic Cars")));

select sum(quantityOrdered) from orderdetails;

select productName, (select sum(quantityOrdered) from orderdetails t2 where t1.productCode = t2.productCode) as 'totalSold' from products t1;


